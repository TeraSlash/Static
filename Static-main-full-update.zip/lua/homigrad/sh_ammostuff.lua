--\\Silk
HGAmmo_MaxKeyBits = 13

if(SERVER)then
	util.AddNetworkString("HGAmmo(TranslateSilkToEntity)")
else
	HGAmmo_PhysSilkTranslationExpectedEntitiesTable = HGAmmo_PhysSilkTranslationExpectedEntitiesTable or {}
	HGAmmo_PhysSilkTranslationTable = HGAmmo_PhysSilkTranslationTable or {}
	
	local function translate_silk_to_ent(ent, bullet_key)
		local translation_info = HGAmmo_PhysSilkTranslationTable[bullet_key]
		
		if(translation_info)then
			if(ent.Silks)then
				for key, silk in pairs(ent.Silks) do
					silk:Die()
				end
			end
		
			for key, silk in pairs(translation_info.Silks) do
				silk.Entity = ent
			end
		
			ent.Silks = translation_info.Silks
			HGAmmo_PhysSilkTranslationTable[bullet_key] = nil
		end
	end
	
	hook.Add("Think", "HGAmmo_PhysSilkTranslationTable", function()
		for bullet_key, translation_info in pairs(HGAmmo_PhysSilkTranslationTable) do
			if(translation_info.DeathTime <= CurTime())then
				for key, silk in pairs(translation_info.Silks) do
					silk:Die()
				end
				
				HGAmmo_PhysSilkTranslationTable[bullet_key] = nil
			end
		end
	end)
	
	hook.Add("NotifyShouldTransmit", "HGAmmo_PhysSilkTranslationTable", function(ent, state)
		if(state == true)then
			local ent_id = ent:EntIndex()
			
			if(HGAmmo_PhysSilkTranslationExpectedEntitiesTable[ent_id])then
				translate_silk_to_ent(ent, HGAmmo_PhysSilkTranslationExpectedEntitiesTable[ent_id])
				
				HGAmmo_PhysSilkTranslationExpectedEntitiesTable[ent_id] = nil
			end
		end
	end)
	
	net.Receive("HGAmmo(TranslateSilkToEntity)", function(len, ply)
		-- Entity(1):ChatPrint(12312)
		local bullet_key = net.ReadUInt(hg.PhysBullet.MaxKeyBits)
		local ent_id = net.ReadUInt(HGAmmo_MaxKeyBits)
		local ent = Entity(ent_id)
		
		if(IsValid(ent))then
			translate_silk_to_ent(ent, bullet_key)
		else
			HGAmmo_PhysSilkTranslationExpectedEntitiesTable[ent_id] = bullet_key
		end
	end)
end
--//

--\\Common Function Overrides
local function scrape_blood(self, trace, len, len_before)
	if(SERVER)then
		if(trace and !trace.HitSky)then
			if(trace.Entity.organism)then
				local hit_organism = trace.Entity.organism
				hit_organism.pain = (hit_organism.pain or 0) + 60
				hit_organism.disorientation = (hit_organism.disorientation or 0) + 5
			else--if(trace.Entity:IsNPC() or trace.Entity:IsNextBot())then
				local dmg = DamageInfo()
				
				if(IsValid(self.Shooter))then
					dmg:SetAttacker(self.Shooter)
				else
					dmg:SetAttacker(game.GetWorld())
				end
				
				dmg:SetDamageType(DMG_DISSOLVE)
				dmg:SetDamage(80)
				trace.Entity:TakeDamageInfo(dmg)
			end
			
			local effect_data = EffectData()
			
			effect_data:SetOrigin(trace.HitPos)
			util.Effect("BloodImpact", effect_data)
		end
	end
	
	-- self:Die()
end

local function onstopped_blood(self, last_unsure_penetration_pos, reason, trace)
	scrape_blood(self, trace, len, len_before)
end

local function postricochet_blood(self, new_vel_normal, len, ricochet, ang_diff, len_before, trace)
	scrape_blood(self, trace, len, len_before)
end

local function postpenetration_blood(self, new_vel_normal, len, ricochet, ang_diff, len_before, trace)
	scrape_blood(self, trace, len, len_before)
end

local function draw_silk(self)
	if(IsValid(self.Draw_Model))then
		--
	else
		local model_ent = ClientsideModel(self.FunctionInfo.Model)
		self.Draw_Model = model_ent
	end
	
	local model_ent = self.Draw_Model
	local vel_ang = self.Vel:Angle()
	
	model_ent:SetPos(self.Pos)
	model_ent:SetAngles(vel_ang)
	
	--if(hg.PhysSilk)then
	--	if(!self.DesiredSilks)then
	--		self.DesiredSilks = self.FunctionInfo.DesiredSilks
	--	end
	--	
	--	self.Silks = self.Silks or {}	--; TODO, Network translation to entity
--
	--	for silk_desired_key, silk_desired in ipairs(self.DesiredSilks) do
	--		local desired_pos, _ = LocalToWorld(silk_desired.EntityOffset, angle_zero, self.Pos, vel_ang)
	--		
	--		if(IsValid(self.Silks[silk_desired_key]))then
	--			self.Silks[silk_desired_key].Pos = desired_pos
	--		else
	--			local silk = table.Copy(silk_desired)	--; WARNING POINTERS
	--			silk.Pos = desired_pos
	--			self.Silks[silk_desired_key] = hg.PhysSilk.CreateSilk(silk, true)
	--		end
	--	end
	--end
	-- if(self.PathPoints)then
		-- local color = self.TracerSetings.TracerColor or color_white
		
		-- render.SetColorMaterial()
		-- render.StartBeam(math.min(#self.PathPoints, self.TracerSetings.MaxPathPoints))
		
		-- for i = math.max(#self.PathPoints - self.TracerSetings.MaxPathPoints, 1), #self.PathPoints do
			-- render.AddBeam(self.PathPoints[i], self.TracerSetings.TracerWidth or 0.4, 1, color)
		-- end
		
		-- render.EndBeam()
	-- end
end

local function onstopped_silk(self, last_unsure_penetration_pos, reason, trace)
	if(SERVER)then
		if(!trace or !trace.HitSky)then
			local normal = self.Vel:GetNormalized()
			local projectile = ents.Create(self.FunctionInfo.Ent)
			projectile:SetPos(self.Pos)
			projectile:SetAngles(normal:Angle())
			projectile:Spawn()
			self.SpawnedEntity = projectile

			if(trace)then
				projectile:Hit(trace.Entity, trace.HitPos - normal * 10, trace.PhysicsBone, normal)
			end
		end
	end
end

local function arrow_hit(self, last_unsure_penetration_pos, reason, trace)
	if(SERVER)then
		if(!trace or !trace.HitSky)then
			local normal = -self.Vel:GetNormalized()
			local projectile = ents.Create(self.FunctionInfo.Ent)
			projectile:SetPos(self.Pos)
			projectile:SetAngles(normal:Angle())
			projectile:Spawn()
			self.SpawnedEntity = projectile
			
			if(trace)then
				projectile:Hit(trace.Entity, trace.HitPos + normal * -4, trace.PhysicsBone, normal)
			end
		end
	end
end

local function preremove_silk(self)
	if(IsValid(self.Draw_Model))then
		self.Draw_Model:Remove()
	end
	
	if(CLIENT and self.Silks)then
		HGAmmo_PhysSilkTranslationTable[self.Key] = {	--; СЕЛФ КЕУ МОЖЕТ БЫТЬ ОДИН И ТОТ ЖЕ У 2 ПУЛЬ ЕСЛИ ПРОШЛАЯ УСПЕЛА УДАЛИТЬСЯ
			Silks = self.Silks,
			DeathTime = CurTime() + 1,
		}
	end
end

local function postremove_silk(self)
	if(SERVER)then
		if(IsValid(self.SpawnedEntity))then
			net.Start("HGAmmo(TranslateSilkToEntity)")
				net.WriteUInt(self.Key, hg.PhysBullet.MaxKeyBits)
				net.WriteUInt(self.SpawnedEntity:EntIndex(), HGAmmo_MaxKeyBits)
			net.SendPVS(self.SpawnedEntity:GetPos())
			-- net.Broadcast()	--; PLUG
		end
	end
end

--=\\Scheduled explosions
APScheduledExplosions = APScheduledExplosions or {}

hook.Add("Think", "APScheduledExplosions", function()	--; AimPoint Mr.Point
	for id, coroutine_example in pairs(APScheduledExplosions) do
		if(!coroutine.resume(coroutine_example))then
			APScheduledExplosions[id] = nil
		end
	end
end)
--=//

--=\\Explosive Projectile
local function draw_explosive(self)
	if(IsValid(self.Draw_Model))then
		--
	else
		local model_ent = ClientsideModel(self.FunctionInfo.Model)
		self.Draw_Model = model_ent
	end
	
	local model_ent = self.Draw_Model
	local vel_ang = self.Vel:Angle()
	
	model_ent:SetPos(self.Pos)
	model_ent:SetAngles(vel_ang)
end

local function preremove_explosive(self)
	if(IsValid(self.Draw_Model))then
		self.Draw_Model:Remove()
	end
end

local function onstopped_explosive(self, last_unsure_penetration_pos, reason, trace)
	if(SERVER)then
		if(!trace or !trace.HitSky)then
			local attacker = self.Shooter
			local pos = self.Pos - self.Vel:GetNormalized() * 2
			local vec_cone = Vector(0, 0, 0)
			local shrapnel_coroutine_id = #APScheduledExplosions + 1
			
			util.ScreenShake(self.Pos, 35, 1, 1, 3000)

			timer.Simple(.01,function()
				ParticleEffect("pcf_jack_airsplode_small3",pos + vector_up * 1,-vector_up:Angle())
			end)

			net.Start("projectileFarSound")
				net.WriteString("m67/m67_detonate_01.wav")
				net.WriteString("m67/m67_detonate_far_dist_03.wav")
				net.WriteVector(pos)
				net.WriteEntity(Entity(0))
				net.WriteBool(false)
				net.WriteString("")
			net.Broadcast()
			
			util.BlastDamage(Entity(0), IsValid(attacker) and attacker or Entity(0), self.Pos, 100, 50)
			hg.ExplosionEffect(self.Pos, 1500 / 0.01905, 250)

			--local effectdata = EffectData()
			--effectdata:SetOrigin(selfPos)
			--effectdata:SetScale(0.9)
			--util.Effect("eff_jack_fragsplosion", effectdata)
	
			timer.Simple(.15,function()
				local coroutine_antilag = coroutine.create(function()
					local last_shrapnel = SysTime()

					for i = 1, 600 do
						last_shrapnel = SysTime()
						local dir = VectorRand(-1, 1)
						
						dir:Normalize()
						
						dir[3] = dir[3] > 0 and math.abs(dir[3] - 0.5) or -math.abs(dir[3] + 0.5)
						
						dir:Normalize()
						
						local bullet = {}
						bullet.Src = pos
						bullet.Spread = vec_cone
						bullet.Force = 4
						bullet.Damage = 40
						bullet.AmmoType = "Metal Debris"
						bullet.Attacker = game.GetWorld()
						bullet.Inflictor = attacker
						bullet.Distance = 567
						bullet.DisableLagComp = true
						bullet.Dir = dir
						
						game.GetWorld():FireLuaBullets(bullet, true)

						last_shrapnel = SysTime() - last_shrapnel

						if(last_shrapnel > 0.001)then
							coroutine.yield()
						end
					end
					
					APScheduledExplosions[shrapnel_coroutine_id] = nil
				end)

				APScheduledExplosions[shrapnel_coroutine_id] = coroutine_antilag
				
				coroutine.resume(coroutine_antilag)
			end)
			util.ScreenShake( self.Pos, 35, 1, 1, 1000, true )
		end
	end
end
--=//
--//

--
local matPistolAmmo = Material("vgui/hud/bullets/low_caliber.png")
local matRfileAmmo = Material("vgui/hud/bullets/high_caliber.png")
local matShotgunAmmo = Material("vgui/hud/bullets/buck_caliber.png")
hg.ammotypes = {
	["5.56x45mm"] = {
		name = "5.56x45 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 155,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 49,
			Force = 44,
			Penetration = 9.2,
			Shell = "556x45",
			Speed = 980,
			Diameter = 5.56,
			Mass = 3.56,
			Icon = matRfileAmmo
		}
	},
	["5.56x45mmm855"] = {
		name = "5.56x45 mm M855",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 90,
			TracerLength = 255,
			TracerWidth = 5,
			TracerColor = Color(0, 255, 0),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 38,
			Force = 44,
			Penetration = 13.5,
			Shell = "556x45",
			Speed = 920,
			Diameter = 5.56,
			Mass = 4,
			Icon = matRfileAmmo
		}
	},
	["5.56x45mmm855a1"] = {
		name = "5.56x45 mm M855A1",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 155,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 34,
			Force = 44,
			Penetration = 20.4,
			Shell = "556x45",
			Speed = 940,
			Diameter = 5.56,
			Mass = 4,
			Icon = matRfileAmmo
		}
	},
	["5.56x45mmm995"] = {
		name = "5.56x45 mm M995",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 155,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 29,
			Force = 29,
			Penetration = 21.9,
			Shell = "556x45",
			Speed = 1030,
			Diameter = 5.56,
			Mass = 3.4,
			Icon = matRfileAmmo
		}
	},
	["7.62x39mmsp"] = {
		name = "7.62x39 mm SP",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 127,
		maxcarry = 120,
		minsplash = 8,
		maxsplash = 8,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 175,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 57,
			Force = 45,
			Penetration = 8.2,
			Shell = "762x39",
			Speed = 715,
			AirResistMul = 0.00011,
			Diameter = 7.62,
			Mass = 8.1,
			Icon = matRfileAmmo
		}
	},
	["7.62x39mm"] = {
		name = "7.62x39 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 160,
		maxcarry = 120,
		minsplash = 8,
		maxsplash = 8,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 175,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 48,
			Force = 50,
			Penetration = 12.9,
			Shell = "762x39",
			Speed = 715,
			AirResistMul = 0.00011,
			Diameter = 7.62,
			Mass = 7.9,
			Icon = matRfileAmmo
		}
	},
	["7.62x39mmbp"] = {
		name = "7.62x39 mm BP gzh",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 160,
		maxcarry = 120,
		minsplash = 8,
		maxsplash = 8,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 175,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 47,
			Force = 66,
			Penetration = 18.2,
			Shell = "762x39",
			Speed = 720,
			AirResistMul = 0.00011,
			Diameter = 7.62,
			Mass = 7.9,
			Icon = matRfileAmmo
		}
	},
	[".366tkmfmj"] = {
		name = ".366 TKM",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 160,
		maxcarry = 120,
		minsplash = 8,
		maxsplash = 8,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 175,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 50,
			Force = 50,
			Penetration = 11.5,
			Shell = "366tkm",
			Speed = 650,
			AirResistMul = 0.00011,
			Diameter = 9.58,
			Mass = 13.5,
			Icon = matRfileAmmo
		}
	},
	[".366tkmgeksa"] = {
		name = ".366 TKM 'Geksa'",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 160,
		maxcarry = 120,
		minsplash = 8,
		maxsplash = 8,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 3,
			TracerLength = 175,
			TracerWidth = 3,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 84,
			Force = 50,
			Penetration = 7.9,
			Shell = "366tkm",
			Speed = 550,
			AirResistMul = 0.00011,
			Diameter = 9.58,
			Mass = 15.5,
			Icon = matRfileAmmo
		}
	},
	["5.45x39mm"] = {
		name = "5.45x39 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 155,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 37,
			Force = 35,
			Penetration = 10.2,
			Shell = "545x39",
			Speed = 890,
			Diameter = 5.45,
			Mass = 3.4,
			Icon = matRfileAmmo
		}
	},
	["5.45x39mm7n22"] = {
		name = "5.45x39 mm BP 7N22",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 155,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 33,
			Force = 33,
			Penetration = 17.8,
			Shell = "545x39",
			Speed = 890,
			Diameter = 5.45,
			Mass = 3.4,
			Icon = matRfileAmmo
		}
	},
	["5.45x39mm7n39"] = {
		name = "5.45x39 mm PPBS 7N39",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 155,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 26,
			Force = 26,
			Penetration = 21.9,
			Shell = "545x39",
			Speed = 850,
			Diameter = 5.45,
			Mass = 4.1,
			Icon = matRfileAmmo
		}
	},
	["metal_debris"] = {
		name = "Metal Debris",
		dmgtype = DMG_AIRBOAT + DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 350,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 15,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 16,
			Force = 12,
			Penetration = 8,
			NumBullet = 8,
			Shell = "12x70",
			Speed = 700,
			PhysPenetrationMul = 65,
			AirResistMul = 0.001,
			Diameter = 12,
			Mass = 32/8,
		}
	},
	["12/70gauge"] = {
		name = "12/70 gauge",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 350,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 15,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 16,
			Force = 8,
			Penetration = 7.5,
			NumBullet = 8,
			Shell = "12x70",
			Speed = 400,
			AirResistMul = 0.0003,
			Diameter = 12/8,
			Mass = 32/8,
			Icon = matShotgunAmmo,
			ShellColor = Color(255,0,0)
		}
	},
	["12/70beanbag"] = {
		name = "12/70 beanbag",
		allowed = true,
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 46,
		minsplash = 0,
		maxsplash = 0,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1.5,
			TracerLength = 155,
			TracerWidth = 5,
			TracerColor = Color(70, 78, 36),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 3000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 60,
			Force = 150,
			Penetration = 1.1,
			Shell = "12x70beanbag",
			Spread = Vector(0, 0, 0),
			Speed = 90,
			AirResistMul = 0.0003,
			Diameter = 12,
			Mass = 40,
			Icon = matShotgunAmmo,
			ShellColor = Color(122,122,122)
		}
	},
	["12/70slug"] = {
		name = "12/70 Slug",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 250,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1.5,
			TracerLength = 25,
			TracerWidth = 3,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 115,
			Force = 120,
			Penetration = 10.1,
			Shell = "12x70slug",
			Spread = Vector(0, 0, 0),
			Speed = 430,
			AirResistMul = 0.00015,
			Diameter = 12,
			Mass = 32,
			Icon = matShotgunAmmo,
			ShellColor = Color(12,75,12)
		}
	},
	["12/70rip"] = {
		name = "12/70 RIP",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 250,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1.5,
			TracerLength = 25,
			TracerWidth = 3,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
			
		},
		BulletSettings = {
			Damage = 200,
			Force = 90,
			Penetration = 7.2,
			Shell = "12x70slug",
			Spread = Vector(0, 0, 0),
			Speed = 380,
			AirResistMul = 0.00015,
			Diameter = 12,
			Mass = 20,
			Icon = matShotgunAmmo,
			ShellColor = Color(50,110,90)
		}
	},
	["12/70blank"] = {
		name = "12/70 Blank",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 350,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 15,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 16,
			Force = 8,
			Penetration = 1,
			NumBullet = 8,
			Shell = "12x70blank",
			Speed = 400,
			AirResistMul = 0.0003,
			Diameter = 12/8,
			Mass = 32/8,
			Icon = matShotgunAmmo,
			ShellColor = Color(75,75,155),
			IsBlank = true
		}
	},
	["23x75sh10"] = {
		name = "23x75 SH10",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 450,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 15,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 20,
			Force = 6,
			Penetration = 8.1,
			NumBullet = 10,
			Shell = "23x75sh10",
			Speed = 360,
			AirResistMul = 0.0007,
			Diameter = 23/10,
			Mass = 45/10,
			Icon = matShotgunAmmo,
			ShellColor = Color(255,185,0)
		}
	},
	["23x75sh25"] = {
		name = "23x75 SH25",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 450,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 15,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 20,
			Force = 2,
			Penetration = 7.5,
			NumBullet = 25,
			Shell = "23x75sh25",
			Speed = 360,
			AirResistMul = 0.0007,
			Diameter = 23/25,
			Mass = 32/25,
			Icon = matShotgunAmmo,
			ShellColor = Color(130,130,130)
		}
	},
	["23x75barricade"] = {
		name = "23x75 Barricade",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 450,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 15,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 150,
			Force = 100,
			Penetration = 12.4,
			Shell = "23x75barricade",
			Spread = Vector(0, 0, 0),
			Speed = 400,
			AirResistMul = 0.0009,
			Diameter = 23,
			Mass = 55,
			Icon = matShotgunAmmo,
			ShellColor = Color(255,185,0)
		}
	},
	["23x75zvezda"] = {
		name = "23x75 Zvezda",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 350,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 15,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 1,
			Force = 1,
			Penetration = 1,
			NumBullet = 1,
			Shell = "23x75zvezda",
			Speed = 80,
			AirResistMul = 0.0003,
			Diameter = 12/8,
			Mass = 60,
			Icon = matShotgunAmmo,
			ShellColor = Color(255,185,0),
			Distance = 32,
		}
	},
	["23x75waver"] = {
		name = "23x75 Wave R",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 450,
		maxcarry = 46,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 15,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 80,
			Force = 100,
			Penetration = 2.2,
			Shell = "23x75waver",
			Spread = Vector(0, 0, 0),
			Speed = 120,
			AirResistMul = 0.0008,
			Diameter = 23,
			Mass = 15,
			Icon = matShotgunAmmo,
			ShellColor = Color(255,185,0)
		}
	},
	["20/70gauge"] = { //потом другие добавлю
		name = "20/70 gauge",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 370,
		maxcarry = 50,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 0.8,
			TracerLength = 12,
			TracerWidth = 0.8,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 9000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 12,
			Force = 6,
			Penetration = 7.6,
			NumBullet = 11,
			Shell = "20/70",
			Speed = 410,
			AirResistMul = 0.00025,
			Diameter = 20/6,
			Mass = 24/6,
			Icon = matShotgunAmmo,
			ShellColor = Color(255,150,0)
		}
	},
	["20/70slug"] = {
		name = "20/70 Slug",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 400,
		maxcarry = 50,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 0.8,
			TracerLength = 12,
			TracerWidth = 0.8,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 9000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 120,
			Force = 120,
			Penetration = 9.8,
			Shell = "20/70",
			Spread = Vector(0, 0, 0),
			Speed = 450,
			AirResistMul = 0.00025,
			Diameter = 20,
			Mass = 24,
			Icon = matShotgunAmmo,
			ShellColor = Color(12,75,12)
		}
	},
	["20/70flechette"] = {
		name = "20/70 Flechette",
		allowed = true,
		--dmgtype = DMG_BUCKSHOT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 350,
		maxcarry = 50,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 0.8,
			TracerLength = 12,
			TracerWidth = 0.8,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 9000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 16,
			Force = 6,
			Penetration = 6.1,
			NumBullet = 8,
			Shell = "20/70",
			Speed = 400,
			AirResistMul = 0.00025,
			Diameter = 20/6,
			Mass = 10/6,
			Icon = matShotgunAmmo,
			ShellColor = Color(195,143,0),
		}
	},
	["9x18mm"] = {
		name = "9x18 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 90,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 23,
			Force = 24,
			Penetration = 7.9,
			Shell = "9x18",
			Speed = 315,
			Diameter = 9,
			Mass = 6.1,
			Icon = matPistolAmmo
		}
	},
	["9x18mmpbm"] = {
		name = "9x18 mm PBM",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 90,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 23,
			Force = 24,
			Penetration = 8.1,
			Shell = "9x18",
			Speed = 485,
			Diameter = 9,
			Mass = 3.7,
			Icon = matPistolAmmo
		}
	},
	["9x17mm"] = {
		name = "9x17 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 90,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 24,
			Force = 24,
			Penetration = 3.1,
			Shell = "9x18",
			Speed = 290,
			Diameter = 9,
			Mass = 4.8,
			Icon = matPistolAmmo
		}
	},
	["9x19mmparabellum"] = {
		name = "9x19 mm Parabellum",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 25,
			Force = 25,
			Penetration = 3.8,
			Shell = "9x19",
			Speed = 365,
			Diameter = 9,
			Mass = 7.5,
			Icon = matPistolAmmo
		}
	},
	["9x19mmpbp"] = {
		name = "9x19 mm PBP gzh",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 22,
			Force = 22,
			Penetration = 11.8,
			Shell = "9x19",
			Speed = 535,
			Diameter = 9,
			Mass = 4.1,
			Icon = matPistolAmmo
		}
	},
	["9x19mmqm"] = {
		name = "9x19 mm QuakeMaker",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 48,
			Force = 27,
			Penetration = 3.6,
			Shell = "9x19",
			Speed = 340,
			Diameter = 9,
			Mass = 6.5,
			Icon = matPistolAmmo
		}
	},
	["7.65x17mm"] = {
		name = "7.65x17 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 95,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 21,
			Force = 25,
			Penetration = 3.2,
			Shell = "45acp",
			Speed = 310,
			Diameter = 9,
			Mass = 4.8,
			Icon = matRfileAmmo
		}
	},
	[".40sw"] = {
		name = ".40 SW",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 110,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 28,
			Force = 45,
			Penetration = 4.3,
			Shell = "45acp",
			Speed = 350,
			Diameter = 11.18,
			Mass = 10.7,
			Icon = matPistolAmmo
		}
	},
	[".45acp"] = {
		name = ".45 ACP",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 30,
			Force = 35,
			Penetration = 3.9,
			Shell = "45acp",
			Speed = 260,
			Diameter = 11.19,
			Mass = 14.9,
			Icon = matPistolAmmo
		}
	},
	[".45acpp"] = {
		name = ".45 ACP +P",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 30,
			Force = 35,
			Penetration = 7.8,
			Shell = "45acp",
			Speed = 330,
			Diameter = 11.19,
			Mass = 12.6,
			Icon = matPistolAmmo
		}
	},
	[".45acphydroshock"] = {
		name = ".45 ACP Hydro Shock",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 45,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 52,
			Force = 50,
			Penetration = 3.3,
			Shell = "45acp",
			Speed = 280,
			Diameter = 11.19,
			Mass = 14.9,
			Icon = matPistolAmmo
		}
	},
	["7.62x25mm"] = {
		name = "7.62x25 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 120,
		maxcarry = 100,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 75,
			TracerWidth = 1.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 35,
			Force = 35,
			Penetration = 9,
			Shell = "10mm",
			Speed = 376,
			Diameter = 10,
			Mass = 10,
			Icon = matPistolAmmo
		}
	},
	["9x19mmgreentracer"] = {
		name = "9x19 mm Green Tracer",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 55,
			TracerLength = 85,
			TracerWidth = 5,
			TracerColor = Color(0, 255, 0),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 25,
			Force = 25,
			Penetration = 3.7,
			Shell = "9x19",
			Speed = 340,
			Diameter = 9,
			Mass = 7.6,
			Icon = matPistolAmmo
		}
	},
	[".45rubber"] = {
		name = ".45 Rubber",
		allowed = true,
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 0,
		maxsplash = 0,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 5,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 6000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 30,
			Force = 30,
			Penetration = 0.8,
			Shell = "9x18",
			Speed = 260,
			Diameter = 11.19,
			Mass = 1.5,
			Icon = matPistolAmmo
		}
	},
	["9mmpakblank"] = {
		name = "9mm PAK Blank",
		allowed = true,
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 0,
		maxsplash = 0,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 5,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 6000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 8,
			Force = 5,
			Penetration = 0.5,
			Shell = "9x18",
			Speed = 259,
			Diameter = 11.19,
			Distance = 32,
			Mass = 10,
			Icon = matPistolAmmo
		}
	},
	["9mmpakflashdefense"] = {
		name = "9mm PAK Flash Defense",
		allowed = true,
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 0,
		maxsplash = 0,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 5,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 6000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 5,
			Force = 5,
			Penetration = 0.5,
			Shell = "9x18",
			Speed = 259,
			Diameter = 11.19,
			Distance = 32,
			Mass = 10,
			Icon = matPistolAmmo
		}
	},
	["18x45mmtraumatic"] = {
		name = "18x45mm Traumatic",
		allowed = true,
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 0,
		maxsplash = 0,
		TracerSetings = {
		--[[ -- FLARE AMMO BAZA!!!!!
			TracerBody = Material("particle/particle_glow_05"),
			TracerTail = Material("trails/smoke"),
			TracerHeadSize = 500,
			TracerLength = 350,
			TracerWidth = 60,
			TracerColor = Color(255, 0, 0),
			TracerTPoint1 = 0.1,
			TracerTPoint2 = 0.5,
			TracerSpeed = 2500,
			NoSpin = true,
		]]
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 5,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 6000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 35,
			Force = 32,
			Penetration = 2.3,
			Shell = "50ae",
			Speed = 124,
			Diameter = 18,
			Mass = 11.6,
			Icon = matPistolAmmo
		}
	},
	["18x45mmflashdefense"] = {
		name = "18x45mm Flash Defense",
		allowed = true,
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 80,
		minsplash = 0,
		maxsplash = 0,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1,
			TracerLength = 5,
			TracerWidth = 1,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 6000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 15,
			Force = 10,
			Penetration = 1,
			Shell = "50ae",
			Speed = 250,
			Diameter = 18,
			Distance = 32,
			Mass = 18,
			Icon = matPistolAmmo
		}
	},
	["4.6x30mm"] = {
		name = "4.6x30 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 4,
		maxsplash = 4,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 45,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 23,
			Force = 23,
			Penetration = 8.7,
			Shell = "556x45",
			Speed = 620,
			Diameter = 4.6,
			Mass = 2.6,
			Icon = matRfileAmmo
		}
	},
	["4.6x30mmap"] = {
		name = "4.6x30 mm AP SX",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 4,
		maxsplash = 4,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 2,
			TracerLength = 45,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 22,
			Force = 22,
			Penetration = 11.8,
			Shell = "556x45",
			Speed = 675,
			Diameter = 4.6,
			Mass = 2,
			Icon = matRfileAmmo
		}
	},
	["5.7x28mm"] = {
		name = "5.7x28 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 150,
		minsplash = 4,
		maxsplash = 4,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 45,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 26,
			Force = 26,
			Penetration = 9.1,
			Shell = "556x45",
			Speed = 792,
			Diameter = 5.7,
			Mass = 1.8,
			Icon = matRfileAmmo
		}
	},
	["5.7x28mmap"] = {
		name = "5.7x28 mm SS190",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 150,
		minsplash = 4,
		maxsplash = 4,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 45,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 23,
			Force = 23,
			Penetration = 11.7,
			Shell = "556x45",
			Speed = 716,
			Diameter = 5.7,
			Mass = 2,
			Icon = matRfileAmmo
		}
	},
	[".44remingtonmagnum"] = {
		name = ".44 Remington Magnum",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 150,
		minsplash = 3,
		maxsplash = 3,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 35,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 20000
		},
		BulletSettings = {
			Damage = 40,
			Force = 40,
			Penetration = 9.5,
			Shell = "10mm",
			Speed = 450,
			Diameter = 10.9,
			Mass = 15.6,
			Icon = matPistolAmmo
		}
	},
	[".500s&wmagnum"] = {
		name = ".500 S&W Magnum",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 150,
		maxcarry = 100,
		minsplash = 6,
		maxsplash = 6,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 35,
			TracerWidth = 1.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 60,
			Force = 60,
			Penetration = 16,
			Shell = "50ae",
			Speed = 600,
			Diameter = 12.7,
			Mass = 26,
			Icon = matPistolAmmo
		}
	},
	[".357magnum"] = {
		name = ".357 Magnum",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 130,
		maxcarry = 150,
		minsplash = 2.5,
		maxsplash = 2.5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 35,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 20000
		},
		BulletSettings = {
			Damage = 40,
			Force = 40,
			Penetration = 5.8,
			Shell = "10mm",
			Speed = 440,
			Diameter = 9,
			Mass = 10.2,
			Icon = matPistolAmmo
		}
	},
	[".38special"] = {
		name = ".38 Special",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 110,
		maxcarry = 150,
		minsplash = 2.5,
		maxsplash = 2.5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 35,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 20000
		},
		BulletSettings = {
			Damage = 27,
			Force = 27,
			Penetration = 3.5,
			Shell = "10mm",
			Speed = 290,
			Diameter = 9.1,
			Mass = 10.2,
			Icon = matPistolAmmo
		}
	},
	["14.5x114mmb32"] = { -- Салат ты у нас тут балансище, сделаешь конфетку 
		name = "14.5x114mm B32",
		dmgtype = DMG_BULLET + DMG_AIRBOAT,
		tracer = TRACER_NONE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 10,
		minsplash = 5,
		maxsplash = 5,
		BulletSettings = {
			Damage = 550,
			Force = 100,
			Penetration = 270.2,
			Shell = "50cal",
			Speed = 1000,
			Diameter = 14.5,
			Mass = 64,
			Icon = matRfileAmmo
		}
	},
	["14.5x114mmbztm"] = { -- это тоже самое что и выше просто с трасером :D
		name = "14.5x114mm BZTM",
		dmgtype = DMG_BULLET + DMG_AIRBOAT,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 100,
		maxcarry = 120,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 100,
			TracerLength = 255,
			TracerWidth = 20,
			TracerColor = Color(255,91,0),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 550,
			Force = 100,
			Penetration = 270.2,
			Shell = "50cal",
			Speed = 1000,
			Diameter = 14.5,
			Mass = 64,
			Icon = matRfileAmmo
		}
	},
	["9x39mm"] = {
		name = "9x39 mm",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 150,
		maxcarry = 150,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 75,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 0.5,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 52,
			Force = 42,
			Penetration = 10.9,
			Shell = "762x39",
			Speed = 290,
			Diameter = 9,
			Mass = 16,
			Icon = matRfileAmmo
		}
	},
	["9x39mmsp6"] = {
		name = "9x39 mm SP-6",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 150,
		maxcarry = 150,
		minsplash = 5,
		maxsplash = 5,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 75,
			TracerWidth = 2.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 0.5,
			TracerSpeed = 15000
		},
		BulletSettings = {
			Damage = 50,
			Force = 42,
			Penetration = 16.8,
			Shell = "762x39",
			Speed = 290,
			Diameter = 9,
			Mass = 16,
			Icon = matRfileAmmo
		}
	},
	[".50actionexpress"] = {
		name = ".50 Action Express",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 150,
		maxcarry = 150,
		minsplash = 6,
		maxsplash = 6,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 35,
			TracerWidth = 1.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 52,
			Force = 40,
			Penetration = 9.2,
			Shell = "50ae",
			Speed = 450,
			Diameter = 12.7,
			Mass = 21,
			Icon = matPistolAmmo
		}
	},
	[".50actionexpresscopper"] = {
		name = ".50 Action Express Copper Solid",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 150,
		maxcarry = 150,
		minsplash = 6,
		maxsplash = 6,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 35,
			TracerWidth = 1.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 65,
			Force = 40,
			Penetration = 11.2,
			Shell = "50ae",
			Speed = 470,
			Diameter = 12.7,
			Mass = 20,
			Icon = matPistolAmmo
		}
	},
	[".50actionexpressjhp"] = {
		name = ".50 Action Express JHP",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 150,
		maxcarry = 150,
		minsplash = 6,
		maxsplash = 6,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 35,
			TracerWidth = 1.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 95,
			Force = 110,
			Penetration = 5.4,
			Shell = "50ae",
			Speed = 440,
			Diameter = 12.7,
			Mass = 19.4,
			Icon = matPistolAmmo
		}
	},
	["7.62x51mm"] = {
		name = "7.62x51 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 250,
		maxcarry = 120,
		minsplash = 10,
		maxsplash = 10,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 75,
			TracerWidth = 1.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 65,
			Force = 65,
			Penetration = 14.1,
			Shell = "762x51",
			Speed = 850,
			Diameter = 7.62,
			Mass = 9.5,
			Icon = matRfileAmmo
		}
	},
	["7.62x51mmm993"] = {
		name = "7.62x51 mm M993",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 250,
		maxcarry = 120,
		minsplash = 10,
		maxsplash = 10,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 75,
			TracerWidth = 1.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 74.7,
			Force = 69,
			Penetration = 22.4,
			Shell = "762x51",
			Speed = 910,
			Diameter = 7.62,
			Mass = 8.2,
			Icon = matRfileAmmo
		}
	},
	["7.62x54mm"] = {
		name = "7.62x54 mm",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 250,
		maxcarry = 120,
		minsplash = 11,
		maxsplash = 11,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 75,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 70,
			Force = 70,
			Penetration = 12.3,
			Shell = "762x54",
			Speed = 830,
			Diameter = 7.62,
			Mass = 9.6,
			Icon = matRfileAmmo
		}
	},
	["7.62x54mm7n26"] = {
		name = "7.62x54 mm 7N26",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 250,
		maxcarry = 120,
		minsplash = 11,
		maxsplash = 11,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 75,
			TracerWidth = 2,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 68,
			Force = 68,
			Penetration = 19.3,
			Shell = "762x54",
			Speed = 825,
			Diameter = 7.62,
			Mass = 9.9,
			Icon = matRfileAmmo
		}
	},
	[".338lapuamagnum"] = {
		name = ".338 Lapua Magnum",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 400,
		maxcarry = 120,
		minsplash = 15,
		maxsplash = 15,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 105,
			TracerWidth = 5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 180,
			Force = 60,
			Penetration = 32.2,
			Shell = ".338Lapua",
			Speed = 910,
			Diameter = 8.6,
			Mass = 16.2,
			Icon = matRfileAmmo
		}
	},
	[".22longrifle"] = {
		name = ".22 Long Rifle",
		allowed = true,
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 70,
		maxcarry = 120,
		minsplash = 1,
		maxsplash = 1,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = .5,
			TracerLength = 55,
			TracerWidth = .5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 10000
		},
		BulletSettings = {
			Damage = 16,
			Force = 20,
			Penetration = 2.4,
			Shell = ".22lr",
			Speed = 330,
			Diameter = 5.72,
			Mass = 2.6,
			Icon = matPistolAmmo
		}
	},
	["rpg-7projectile"] = {
		name = "RPG-7 Projectile",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 5000,
		maxcarry = 120,
		minsplash = 10,
		maxsplash = 5
	},
	["12.7x108mm"] = {
		name = "12.7x108 mm",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 550,
		maxcarry = 120,
		minsplash = 20,
		maxsplash = 20,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 150,
			TracerWidth = 8.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 45000
		},
		BulletSettings = {
			Damage = 150,
			Force = 40,
			Penetration = 60.4,
			Shell = "50cal",
			Speed = 820,
			Diameter = 12.7,
			Mass = 48,
			Icon = matRfileAmmo
		}
	},
	["12.7x55mm"] = {
		name = "12.7x55 mm",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 96.8,
		npcdmg = 96.8,
		force = 180,
		maxcarry = 120,
		minsplash = 20,
		maxsplash = 20,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 5,
			TracerLength = 150,
			TracerWidth = 8.5,
			TracerColor = Color(255, 237, 155),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 45000
		},
		BulletSettings = {
			Damage = 255,
			Force = 40,
			Penetration = 21.5,
			Shell = "50cal",
			Speed = 295, --asha it's subsonic rifle... deka you are stupid
			Diameter = 12.7,
			Mass = 48,
			Icon = matRfileAmmo
		}
	},
	["nails"] = {
		name = "Nails",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 50,
		maxcarry = 120,
		minsplash = 10,
		maxsplash = 5
	},
	["armature"] = {
		name = "Armature",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 150,
		maxcarry = 90,
		minsplash = 10,
		maxsplash = 5,
		TracerSetings = {
			MaxPathPoints = 5,
		},
		BulletSettings = {
			Mass = 200,
			Icon = matRfileAmmo,
			Damage = 256.8,
			Force = 30.9,
			Penetration = 50,
		},
		FunctionInfo = {
			Model = "models/crossbow_bolt.mdl",
			--DesiredSilks = {	--; WARNING POINTER
			--	{SegmentsDesiredAmt = 5, SegmentsDesiredWidth = 1, SegmentsDesiredLength = 3, EntityOffset = Vector(2, 0, 0)},
			--	{SegmentsDesiredAmt = 6, SegmentsDesiredWidth = 1, SegmentsDesiredLength = 3, EntityOffset = Vector(2.1, 0, 0)},
			--	{SegmentsDesiredAmt = 10, SegmentsDesiredWidth = 1, SegmentsDesiredLength = 3, EntityOffset = Vector(2, 0, 0)},
			--},
			Ent = "crossbow_projectile",
		},
		BulletFunctions = {
			-- Draw = draw_silk,
			OnStopped = onstopped_silk,
			--PreRemove = preremove_silk,
			--PostRemove = postremove_silk,
		},
	},
	["arrow"] = {
		name = "Arrow",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 5,
		maxcarry = 40,
		minsplash = 10,
		maxsplash = 5,
		TracerSetings = {
			MaxPathPoints = 4,
			TracerWidth = 5,
			TracerColor = Color(15, 15, 15),
		},
		BulletSettings = {
			Mass = 40,
			Icon = matRfileAmmo,
			Damage = 35,
			Speed = 5,
			PhysPenetrationMul = 0.0,
		},
		FunctionInfo = {
			Model = "models/z_city/nmrih/items/arrow/ammo_arrow_single.mdl",
			--DesiredSilks = {	--; WARNING POINTER
			--	{SegmentsDesiredAmt = 5, SegmentsDesiredWidth = 1, SegmentsDesiredLength = 3, EntityOffset = Vector(2, 0, 0)},
			--	{SegmentsDesiredAmt = 6, SegmentsDesiredWidth = 1, SegmentsDesiredLength = 3, EntityOffset = Vector(2.1, 0, 0)},
			--	{SegmentsDesiredAmt = 10, SegmentsDesiredWidth = 1, SegmentsDesiredLength = 3, EntityOffset = Vector(2, 0, 0)},
			--},
			Ent = "arrow_projectile",
		},
		BulletFunctions = {
			-- Draw = draw_silk,
			OnStopped = arrow_hit,
			--PreRemove = preremove_silk,
			--PostRemove = postremove_silk,
		},
	},
	["grenade_30x29mm"] = {
		name = "Grenade 30x29mm",
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 150,
		maxcarry = 120,
		minsplash = 10,
		maxsplash = 5,
		TracerSetings = {
			MaxPathPoints = 5,
		},
		BulletSettings = {
			Mass = 200,
			PhysPenetrationMul = 0.0,
			-- Speed = 185,
			Speed = 55,	--; Comically slow
			LifeTime = 15,
			Shell = "12guage",
			Icon = matRfileAmmo
		},
		FunctionInfo = {
			Model = "models/Items/AR2_Grenade.mdl",
			-- Ent = "crossbow_projectile",
		},
		BulletFunctions = {
			Draw = draw_explosive,
			OnStopped = onstopped_explosive,
			PreRemove = preremove_explosive,
		},
	},
	["pulse"] = {
		name = "Pulse",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 120,
		maxcarry = 120,
		minsplash = 16,
		maxsplash = 16,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 25,
			TracerLength = 150,
			TracerWidth = 1.5,
			TracerColor = Color(155, 232, 255),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 58,
			Force = 50,
			Penetration = 23.6,
			Shell = "Pulse",
			Speed = 1000,
			Diameter = 10,
			Mass = 10,
			Icon = matRfileAmmo,
			noricochet = true,
		}
	},
	["blood"] = {
		name = "Blood",
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		noentity = true,
		plydmg = 0,
		npcdmg = 0,
		force = 120,
		maxcarry = 120,
		minsplash = 16,
		maxsplash = 16,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 25,
			TracerLength = 150,
			MaxPathPoints = 10,
			TracerWidth = 4.5,
			TracerColor = Color(255, 0, 0),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
		BulletSettings = {
			Damage = 0,
			Force = 50,
			Penetration = 17,
			-- Shell = "Pulse",
			Speed = 1000,
			Diameter = 10,
			Mass = 10,
			Icon = matRfileAmmo
		},
		BulletFunctions = {
			-- Hit = hit_blood,
			OnStopped = onstopped_blood,
			PostRicochet = postricochet_blood,
			PostPenetration = postpenetration_blood,
		}
	},
	["tasercartridge"] = {
		name = "Taser Cartridge",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 120,
		maxcarry = 120,
		minsplash = 16,
		maxsplash = 16,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 25,
			TracerLength = 150,
			TracerWidth = 1.5,
			TracerColor = Color(155, 232, 255),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 25000
		},
	},
	["20mm"] = {
		name = "20mm",
		dmgtype = DMG_BULLET,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 230,
		maxcarry = 20,
		minsplash = 8,
		maxsplash = 10,
		TracerSetings = {
			TracerBody = Material("effects/scotchmuzzleflashw"),
			TracerTail = Material("effects/fas_bullet"),
			TracerHeadSize = 80,
			TracerLength = 128,
			TracerWidth = 32,
			TracerColor = Color(120, 120, 120),
			TracerTPoint1 = 0.8,
			TracerTPoint2 = 1,
			TracerSpeed = 6000
		},
		BulletSettings = {
			Damage = 100,
			Force = 120,
			Penetration = 1,
			Shell = "",
			Speed = 170,
			Diameter = 20,
			Mass = 50,
			Icon = matShotgunAmmo
		}
	},
	["tranquilizerdarts"] = {
		name = "Tranquilizer Darts",
		dmgtype = DMG_CLUB,
		tracer = TRACER_LINE,
		plydmg = 0,
		npcdmg = 0,
		force = 50,
		maxcarry = 30,
		minsplash = 0,
		maxsplash = 0,
		TracerSetings = {
			TracerBody = Material("particle/fire"),
			TracerTail = Material("effects/laser_tracer"),
			TracerHeadSize = 1.5,
			TracerLength = 155,
			TracerWidth = 5,
			TracerColor = Color(37, 78, 36),
			TracerTPoint1 = 0.25,
			TracerTPoint2 = 1,
			TracerSpeed = 3000,
			NoSpin = true,
		},
		BulletSettings = {
			Damage = 5,
			Force = 10,
			Penetration = 0,
			Shell = "9x19",
			Spread = Vector(0, 0, 0),
			Speed = 650,
			AirResistMul = 0.0002,
			Diameter = 9,
			Mass = 18,
			Icon = matPistolAmmo,
			tranquilizer = true,
		}
	},
}

local ammotypes = hg.ammotypes
local ammoents = {
	["5.56x45mm"] = {
		Icon = "vgui/hud/556fmj.png",
		Material = "models/hmcd_ammobox_556",
		Scale = 1
	},
	["5.56x45mmm855"] = {
		Icon = "vgui/hud/m855.png",
		Material = "models/hmcd_ammobox_556",
		Scale = 1
	},
	["5.56x45mmm855a1"] = {
		Icon = "vgui/hud/m855a1.png",
		Material = "models/hmcd_ammobox_556",
		Scale = 1
	},
	["5.56x45mmm995"] = {
		Icon = "vgui/hud/m995.png",
		Model = "models/zcity/ammo/ammo_556x45_ap.mdl",
		Scale = 1,
	},
	["7.62x39mm"] = {
		Icon = "vgui/hud/ps.png",
		Model = "models/items/ammo_76239.mdl",
		Scale = 1
	},
	["7.62x51mm"] = {  
		Icon = "vgui/hud/m80.png",
		Model = "models/items/ammo_76251.mdl",
		Scale = 1,
		Count = 25,
	},
	["7.62x51mmm993"] = {  
		Icon = "vgui/hud/m993.png",
		Model = "models/items/ammo_76251.mdl",
		Scale = 1,
		Count = 25,
	},
	["7.62x54mm"] = {
		Icon = "vgui/hud/std.png",
		Model = "models/zcity/ammo/ammo_762x54_7h1.mdl",
		Scale = 1,
		Count = 25,
	},
	["7.62x54mm7n26"] = {
		Icon = "vgui/hud/t46m.png",
		Model = "models/zcity/ammo/ammo_762x54_7h1.mdl",
		Scale = 1,
		Count = 25,
	},
	["7.62x39mmsp"] = {
		Icon = "vgui/hud/hp.png",
		Model = "models/zcity/ammo/ammo_762x54_7h1.mdl",
		Scale = 1,
		Count = 25,
		Color = Color(14,54,22)
	},
	["7.62x39mmbp"] = {
		Icon = "vgui/hud/bp.png",
		Model = "models/zcity/ammo/ammo_762x54_7h1.mdl",
		Scale = 1,
		Count = 25,
		Color = Color(14,54,22)
	},
	[".366tkmfmj"] = {
		Icon = "vgui/hud/366fmj.png",
		Model = "models/items/ammo_76239.mdl",
		Scale = 1
	},
	[".366tkmgeksa"] = {
		Icon = "vgui/hud/geksa.png",
		Model = "models/items/ammo_76239.mdl",
		Scale = 1
	},
	["5.45x39mm"] = {
		Icon = "vgui/hud/545ps.png",
		Model = "models/zcity/ammo/ammo_545x39_fmj.mdl",
		Scale = 1,
	},
	["5.45x39mm7n22"] = {
		Icon = "vgui/hud/545bp.png",
		Model = "models/zcity/ammo/ammo_545x39_fmj.mdl",
		Scale = 1,
	},
	["5.45x39mm7n39"] = {
		Icon = "vgui/hud/ppbs.png",
		Model = "models/zcity/ammo/ammo_545x39_fmj.mdl",
		Scale = 1,
	},
	["metal_debris"] = {
		Material = "models/hmcd_ammobox_12",
		Scale = 1.1,
		Count = 12,
		Spawnable = false
	},
	["12/70gauge"] = {
		Icon = "vgui/hud/def.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.1,
		Count = 12,
	},
	["12/70beanbag"] = {
		Icon = "vgui/hud/flech.png",
		Model = "models/ammo/beanbag12_ammo.mdl",
		Scale = 1,
		Count = 12,
	},
	["12/70slug"] = {
		Icon = "vgui/hud/12copper.png",
		Model = "models/zcity/ammo/ammo_12x76_zhekan.mdl",
		Scale = 1.1,
		Count = 12,
		Color = Color(125, 155, 95)
	},
	["12/70rip"] = {
		Icon = "vgui/hud/p3.png",
		Model = "models/zcity/ammo/ammo_12x76_zhekan.mdl",
		Scale = 1.1,
		Count = 12,
		Color = Color(22, 168, 221)
	},
	["12/70blank"] = {
		Icon = "vgui/hud/slug.png",
		Model = "models/ammo/beanbag12_ammo.mdl",
		Scale = 1,
		Count = 12,
		Color = Color(22, 168, 221)
	},
	["23x75sh10"] = {
		Icon = "vgui/hud/sh.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.2,
		Count = 12,
	},
	["23x75sh25"] = {
		Icon = "vgui/hud/sh25.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.2,
		Count = 12,
	},
	["23x75barricade"] = {
		Icon = "vgui/hud/bar.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.2,
		Count = 12,
	},
	["23x75zvezda"] = {
		Icon = "vgui/hud/z.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.2,
		Count = 12,
	},
	["23x75waver"] = {
		Icon = "vgui/hud/sh.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.2,
		Count = 12,
	},
	["20/70gauge"] = {
		Icon = "vgui/hud/20ga_std.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.1,
		Count = 12,
		Color = Color(255,150,0)
	},
	["20/70slug"] = {
		Icon = "vgui/hud/20ga_p6u.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.1,
		Count = 12,
		Color(0,84,0)
	},
	["20/70flechette"] = {
		Icon = "vgui/hud/20ga_p3.png",
		Material = "models/hmcd_ammobox_12",
		Scale = 1.1,
		Count = 12,
		Color = Color(154,154,154)
	},
	["9x18mm"] = {
		Icon = "vgui/hud/bullet.png",
		Model = "models/zcity/ammo/ammo_9x18_pmm.mdl",
		Scale = 1
	},
	["9x18mmpbm"] = {
		Icon = "vgui/hud/bullet.png",
		Model = "models/zcity/ammo/ammo_9x18_pmm.mdl",
		Scale = 1
	},
	["9x17mm"] = {
		Icon = "vgui/hud/bullet.png",
		Model = "models/zcity/ammo/ammo_9x18_pmm.mdl",
		Scale = 1
	},
	["9x19mmparabellum"] = {
		Icon = "vgui/hud/m882.png",
		Material = "models/hmcd_ammobox_9",
		Scale = 0.8,
	},
	["9x19mmpbp"] = {
		Icon = "vgui/hud/pbpgzh.png",
		Material = "models/hmcd_ammobox_9",
		Scale = 0.8,
	},
	["9x19mmgreentracer"] = {
		Icon = "vgui/hud/tracer.png",
		Color = Color(0, 255, 0),
		Scale = 0.8
	},
	["9x19mmqm"] = {
		Icon = "vgui/hud/quake.png",
		Material = "models/hmcd_ammobox_9",
		Color = Color(0, 26, 255),
		Scale = 0.8
	},
	[".45rubber"] = {
		Icon = "vgui/hud/45rub.png",
		Model = "models/ammo/beanbag9_ammo.mdl",
		Scale = 1
	},
	["9mmpakblank"] = {
		Icon = "vgui/hud/45rub.png",
		Model = "models/ammo/beanbag9_ammo.mdl",
		Scale = 1
	},
	["9mmpakflashdefense"] = {
		Icon = "vgui/hud/45rub.png",
		Model = "models/ammo/beanbag9_ammo.mdl",
		Scale = 1
	},
	["18x45mmtraumatic"] = {
		Icon = "vgui/hud/1845t.png",
		Model = "models/zcity/ammo/ammo_12x70_buck.mdl",
		Scale = 0.8,
		Color = Color(87, 110, 82),
		Count = 4,
	},
	["18x45mmflashdefense"] = {
		Icon = "vgui/hud/1845t.png",
		Model = "models/zcity/ammo/ammo_12x76_dart.mdl",
		Scale = 0.8,
		Color = Color(119, 47, 47),
		Count = 4,
	},
	["4.6x30mm"] = {
		Icon = "vgui/hud/47fmj.png",
		Model = "models/4630_ammobox.mdl",
		Scale = 1,
	},
	["4.6x30mmap"] = {
		Icon = "vgui/hud/47ap.png",
		Model = "models/4630_ammobox.mdl",
		Scale = 1,
	},
	[".44remingtonmagnum"] = {
		Icon = "vgui/hud/44hp.png",
		Material = "models/hmcd_ammobox_22",
		Color = Color(125, 155, 95),
		Scale = 0.8,
		Count = 20,
	},
	[".500s&wmagnum"] = {
		Icon = "vgui/hud/50fmj.png",
		Material = "models/hmcd_ammobox_22",
		Color = Color(255, 255, 125),
		Scale = 1,
		Count = 20,
	},
	[".357magnum"] = {
		Icon = "vgui/hud/357fmj.png",
		Model = "models/Items/357ammobox.mdl",
		Scale = 0.5,
		Count = 20,
	},
	[".38special"] = {
		Icon = "vgui/hud/38special.png",
		Material = "models/hmcd_ammobox_38",
		Color = Color(255, 255, 255),
		Scale = 0.8,
		Count = 20,
	},
	["9x39mm"] = {
		Icon = "vgui/hud/sp5.png",
		Model = "models/zcity/ammo/ammo_9x39_sp5.mdl",
		Scale = 1,
		Count = 20,
	},
	["9x39mmsp6"] = {
		Icon = "vgui/hud/sp6.png",
		Model = "models/zcity/ammo/ammo_9x39_sp5.mdl",
		Scale = 1,
		Count = 20,
	},
	["5.7x28mm"] = {
		Icon = "vgui/hud/ss198lf.png",
		Material = "models/hmcd_ammobox_22",
		Scale = 1.2,
		Color = Color(125, 155, 95)
	},
	["5.7x28mmap"] = {
		Icon = "vgui/hud/ss190.png",
		Material = "models/hmcd_ammobox_22",
		Scale = 1.2,
		Color = Color(125, 155, 95)
	},
	[".50actionexpress"] = {
		Icon = "vgui/hud/50fmj.png",
		Material = "models/hmcd_ammobox_22",
		Scale = 1,
		Color = Color(255, 255, 125),
		Count = 20,
	},
	[".50actionexpressjhp"] = {
		Icon = "vgui/hud/50jhp.png",
		Material = "models/hmcd_ammobox_22",
		Scale = 1,
		Color = Color(73, 73, 32),
		Count = 20,
	},
	[".50actionexpresscopper"] = {
		Icon = "vgui/hud/50c.png",
		Material = "models/hmcd_ammobox_22",
		Scale = 1,
		Color = Color(245, 149, 5),
		Count = 20,
	},
	["14.5x114mmbztm"] = {
		Icon = "vgui/hud/bztmzcity",
		Material = "models/hmcd_ammobox_22",
		Scale = 1,
		Color = Color(246, 129, 5),
		Count = 20,
	},
	["14.5x114mmb32"] = {
		Icon = "vgui/hud/hmcd_round_145",
		Material = "models/hmcd_ammobox_22",
		Scale = 1,
		Color = Color(55, 55, 2),
		Count = 20,
	},
	[".338lapuamagnum"] = {
		Icon = "vgui/hud/338fmj.png",
		Material = "models/hmcd_ammobox_792",
		Scale = 1,
		Color = Color(125, 255, 125),
		Count = 20,
	},
	["12.7x108mm"] = {
		Icon = "vgui/hud/127108.png",
		Material = "models/hmcd_ammobox_792",
		Scale = 1.6,
		Color = Color(225, 122, 125),
		Count = 20,
	},
	["12.7x55mm"] = {
		Icon = "vgui/hud/ps12.png",
		Material = "models/hmcd_ammobox_792",
		Scale = 1.2,
		Color = Color(204, 241, 140),
		Count = 20,
	},
	[".22longrifle"] = {
		Icon = "vgui/hud/22lr.png",
		Material = "models/hmcd_ammobox_22",
		Scale = 1
	},
	["rpg-7projectile"] = {
		Icon = "pwb/sprites/hmcd_round_rpg",
		Model = "models/weapons/tfa_ins2/w_rpg7_projectile.mdl",
		Count = 1
	},
	["nails"] = {
		Icon = "vgui/hud/hmcd_nail",
		Material = "models/fello/f_matchboxtex", -- "models/hmcd_nails"
		Scale = 1,
		Count = 3,
	},
	["armature"] = {
		Icon = "vgui/hud/hmcd_crossbow_bolt",
		Model = "models/Items/CrossbowRounds.mdl",
		Count = 5
	},
	["arrow"] = {
		Icon = "vgui/hud/hmcd_round_arrow",
		Model = "models/z_city/nmrih/items/arrow/ammo_arrow_box.mdl",
		Count = 5
	},
	["grenade_30x29mm"] = {
		Icon = "vgui/hud/ahuetzcity",
		Model = "models/Items/BoxMRounds.mdl",
		Count = 15
	},
	["pulse"] = {
		Icon = "vgui/hud/hmcd_round_impulse",
		Model = "models/Items/combine_rifle_cartridge01.mdl",
		Count = 30
	},
	["tasercartridge"] = {
		Icon = "vgui/hud/hmcd_taser_cartridge",
		Model = "models/ammo/taser_ammo.mdl",
		Count = 1,
		Material = "models/defcon/taser/taser",
	},
	[".45acp"] = {
		Icon = "vgui/hud/45fmj.png",
		Model = "models/zcity/ammo/ammo_1143x23_fmj.mdl"
	},
	[".45acpp"] = {
		Icon = "vgui/hud/45p.png",
		Model = "models/zcity/ammo/ammo_1143x23_fmj.mdl"
	},
	["7.62x25mm"] = {
		Icon = "vgui/hud/akbs.png",
		Material = "models/hmcd_ammobox_22",
		Color = Color(155, 149, 95)
	},
	[".45acphydroshock"] = {
		Icon = "vgui/hud/hydra.png",
		Model = "models/zcity/ammo/ammo_1143x23_hydro.mdl"
	},
	["7.65x17mm"] = {
		Icon = "vgui/hud/45fmj.png",
		Model = "models/zcity/ammo/ammo_1143x23_fmj.mdl"
	},
	[".40sw"] = {
		Icon = "vgui/hud/40sw.png",
		Model = "models/zcity/ammo/ammo_1143x23_hydro.mdl"
	},
	["20mm"] = {
		Icon = "vgui/hud/musketballzcity",
		Material = "models/props_c17/paper01",
		Scale = 0.8,
		Count = 4,
	},
	["tranquilizerdarts"] = {
		Icon = "vgui/hud/bullets/low_caliber.png",
		Material = "models/hmcd_ammobox_9",
		Scale = 0.8,
	},
}

hg.ammoents = ammoents

hg.ammotypes["5.56x45mmm856"] = hg.ammotypes["5.56x45mmm855"]
hg.ammotypes["5.56x45mmap"] = hg.ammotypes["5.56x45mmm855a1"]
hg.ammotypes[".366tkm"] = hg.ammotypes[".366tkmfmj"]
ammoents["5.56x45mmm856"] = ammoents["5.56x45mmm855"]
ammoents["5.56x45mmap"] = ammoents["5.56x45mmm855a1"]
ammoents[".366tkm"] = ammoents[".366tkmfmj"]

local function addAmmoTypes()
	for name, tbl in pairs(ammotypes) do
		game.AddAmmoType(tbl)
		
		if(!tbl.noentity)then
			if CLIENT then language.Add(tbl.name .. "_ammo", tbl.name) end
			local ammoent = {}
			ammoent.Base = "ammo_base"
			ammoent.PrintName = tbl.name
			ammoent.Category = "ZCity Ammo"
			ammoent.Spawnable = (tbl.Spawnable and tbl.Spawnable ~= nil) and tbl.Spawnable or true
			ammoent.AmmoCount = ammoents[name].Count or 30
			ammoent.AmmoType = tbl.name
			ammoent.Model = ammoents[name].Model or "models/props_lab/box01a.mdl"
			ammoent.ModelMaterial = ammoents[name].Material or ""
			ammoent.ModelScale = ammoents[name].Scale or 1
			ammoent.Color = ammoents[name].Color or Color(255, 255, 255)
			ammoent.IconOverride = ammoents[name].Icon or "vgui/hud/bullets/high_caliber.png"
			scripted_ents.Register(ammoent, "ent_ammo_" .. name)
		end
	end

	game.BuildAmmoTypes()
	--PrintTable(game.GetAmmoTypes())
end

addAmmoTypes()
hook.Add("Initialize", "init-ammo", addAmmoTypes)

--коэффициент лобового сопротивления также можно рассчитать математически
--11300 - плотность свинца в кг/м3
for i,tbl in pairs(ammotypes) do
	if not tbl.BulletSettings or not tbl.BulletSettings.Diameter or not tbl.BulletSettings.Speed then continue end
	local coef = 8 / (1.2255 * (tbl.BulletSettings.Speed^2) * math.pi * ((tbl.BulletSettings.Diameter / 1000)^2))
	tbl.BulletSettings.AirResistanceCoef = coef
	--local ballistic_coef = tbl.BulletSettings.Mass / 1000 / coef / (math.pi * (tbl.BulletSettings.Diameter / 1000 / 2)^2)
	--неверно
	--print(i,coef,ballistic_coef)
end

local ammotypeshuy = {}
for i,tbl in pairs(table.Copy(ammotypes)) do
	ammotypeshuy[tbl.name] = tbl
	ammotypeshuy[tbl.name].name = i
end

hg.ammotypeshuy = ammotypeshuy

local ammotypesallowed = {}
for i,tbl in pairs(table.Copy(ammotypeshuy)) do
	if not tbl.allowed then continue end
	ammotypesallowed[i] = tbl
end

hg.ammotypesallowed = ammotypesallowed

if CLIENT then
    local blurMat = Material("pp/blurscreen")
    local Dynamic = 0
	local red = Color(75,25,25)
	local panclr = Color( 0, 0, 0, 140)
	local ammoMenuOutline = Color(255, 255, 255, 255)
	local ammoMenuFill = Color(0, 0, 0, 245)
	local ammoMenuGradient = Color(40, 40, 40, 55)
	local ammoMenuButtonIdle = Color(20, 20, 20, 235)
	local ammoMenuButtonHover = Color(34, 34, 34, 235)

	local gradient_u = Material("vgui/gradient-u")
	local gradient_d = Material("vgui/gradient-d")
	BlurBackground = hg.DrawBlur

	local function PaintInnerFrame(self,w,h)
		BlurBackground(self)
		surface.SetDrawColor(ammoMenuFill)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(ammoMenuGradient)
		surface.SetMaterial(gradient_d)
		surface.DrawTexturedRect( 0, 0, w, h )
		surface.SetDrawColor(ammoMenuOutline)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
	end

	local function PaintButton(self,w,h)
		surface.SetDrawColor(self:IsHovered() and ammoMenuButtonHover or ammoMenuButtonIdle)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(ammoMenuGradient)
		surface.SetMaterial(gradient_u)
		surface.DrawTexturedRect( 0, 0, w, h )
		surface.SetDrawColor(ammoMenuOutline)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
	end

	local function PaintCloseButton(self, w, h)
		surface.SetDrawColor(self:IsHovered() and ammoMenuButtonHover or ammoMenuButtonIdle)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(ammoMenuOutline)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText(self:GetText(), "ZCity_Menu_Settings_Small", w * 0.5, h * 0.5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local function PaintCountSlider(self, w, h, frac)
		local trackY = h / 2 - 1
		surface.SetDrawColor(20, 20, 20, 230)
		surface.DrawRect(0, trackY, w, 2)
		surface.SetDrawColor(255, 255, 255, 220)
		surface.DrawRect(0, trackY, w * frac, 2)
		local knobX = math.Clamp(w * frac - 3, 0, w - 6)
		draw.RoundedBox(2, knobX, h / 2 - 4, 6, 8, Color(245, 245, 245))
	end

    function AmmoMenu(ply)
        local ammodrop = 0
        if !ply:Alive() then return end
        local Frame = vgui.Create( "ZFrame" )
        Frame:SetTitle( "" ) -- "Ammunition"
        Frame:SetSize( 250,360 )
        Frame:Center()			
        Frame:MakePopup()
		Frame:SetVisible(false)
		Frame:SetColorBG(ammoMenuFill)
		Frame:SetColorBR(ammoMenuOutline)
		if IsValid(Frame.btnClose) then
			Frame.btnClose:SetVisible(false)
			Frame.btnClose:SetMouseInputEnabled(false)
		end

		local CloseButton = Frame:Add("DButton")
		CloseButton:SetPos(Frame:GetWide() - 38, 10)
		CloseButton:SetSize(28, 28)
		CloseButton:SetText("X")
		CloseButton.Paint = PaintCloseButton
		CloseButton.DoClick = function()
			Frame:Close()
		end

		local Title = vgui.Create("DLabel", Frame)
		Title:SetPos(14, 12)
		Title:SetTextColor(color_white)
		Title:SetText("ammo")
		Title:SetFont("ZCity_Menu_Settings_Small")
		Title:SizeToContents()

        local DPanel = vgui.Create( "DScrollPanel", Frame )
        DPanel:SetPos( 10, 46 )
        DPanel:SetSize( 230, 230 )
        DPanel.Paint = function( self, w, h )
			PaintInnerFrame(self, w, h)
        end

		local sbar = DPanel:GetVBar()
		sbar:SetHideButtons(true)

		function sbar:Paint(w, h)
			surface.SetDrawColor(16, 16, 16, 220)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(ammoMenuOutline)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end

		function sbar.btnGrip:Paint(w, h)
			self.lerpcolor = Lerp(FrameTime() * 10, self.lerpcolor or 0.3, self:IsHovered() and 0.5 or 0.3)
			local col = 255 * self.lerpcolor
			surface.SetDrawColor(col, col, col, 255)
			surface.DrawRect(0, 0, w, h)
		end

		local countLabel = vgui.Create( "DLabel", Frame )
		countLabel:SetPos( 25, 293 )
		countLabel:SetTextColor(color_white)
		countLabel:SetText( "Count:" )
		countLabel:SetFont("HomigradFontSmall")
		countLabel:SizeToContents()

		local sliderMin, sliderMax = 0, 60
		local sliderFrac = 0
		local sliderValue = vgui.Create("DLabel", Frame)
		sliderValue:SetPos(220, 309)
		sliderValue:SetSize(20, 20)
		sliderValue:SetText("")
		sliderValue.Paint = function(self, w, h)
			draw.SimpleText(tostring(ammodrop), "HomigradFontSmall", w, h * 0.5, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end

		local sliderBg = vgui.Create("DButton", Frame)
		sliderBg:SetPos(74, 309)
		sliderBg:SetSize(132, 24)
		sliderBg:SetText("")

		local function UpdateAmmoSlider(frac)
			sliderFrac = math.Clamp(frac, 0, 1)
			ammodrop = math.Round(sliderMin + sliderFrac * (sliderMax - sliderMin))
		end

		local isDragging = false

		function sliderBg:Paint(w, h)
			PaintCountSlider(self, w, h, sliderFrac)
		end

		function sliderBg:OnMousePressed(mouseCode)
			if mouseCode == MOUSE_LEFT then
				isDragging = true
				self:MouseCapture(true)
				local x = self:CursorPos()
				UpdateAmmoSlider(x / self:GetWide())
			end
		end

		function sliderBg:OnMouseReleased(mouseCode)
			if mouseCode == MOUSE_LEFT then
				isDragging = false
				self:MouseCapture(false)
			end
		end

		function sliderBg:OnCursorMoved(x, y)
			if isDragging then
				UpdateAmmoSlider(x / self:GetWide())
			end
		end

        local ammos = LocalPlayer():GetAmmo()

        for k,v in pairs(ammos) do
            local DermaButton = vgui.Create( "DButton", DPanel ) 
            DermaButton:SetText( game.GetAmmoName( k )..": "..v )	
            DermaButton:SetTextColor( Color(255,255,255) )	
			DermaButton:SetFont("HomigradFontVSmall")
            DermaButton:SetPos( 0, 0 )	
            DermaButton:Dock( TOP )
            DermaButton:DockMargin( 4, 4, 4, 0 )	
            DermaButton:SetSize( 120, 28 )

            DermaButton.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
				PaintButton(self, w, h)
            end				
            DermaButton.DoClick = function()
                --print( math.min(ammodrop,v),game.GetAmmoName( k ))				
                net.Start( "drop_ammo" )
                    net.WriteFloat( k )
                    net.WriteFloat( math.min(ammodrop,v) )
                net.SendToServer()
                Frame:Close()
            end

            DermaButton.DoRightClick = function()
                net.Start( "drop_ammo" )
                    net.WriteFloat( k )
                    net.WriteFloat( math.min(v,v) )
                net.SendToServer()
                Frame:Close()
            end
        end
        local DLabel = vgui.Create( "DLabel", Frame )
        DLabel:SetPos( 10, 338 )
		DLabel:SetTextColor(color_white)
        DLabel:SetText( "LMB - Drop count\nRMB - Drop all" )
		DLabel:SetFont("HomigradFontVSmall")
        DLabel:SizeToContents()
		Frame:SlideDown(0.5)
    end

    concommand.Add( "hg_ammomenu", function( ply, cmd, args )
        AmmoMenu(ply)
    end )

	hook.Add("radialOptions", "hg-ammomenu", function()
		local organism = LocalPlayer().organism or {}
		if not organism.otrub and table.Count(LocalPlayer():GetAmmo()) > 0 then
			hg.radialOptions[#hg.radialOptions + 1] = {
				function()
					RunConsoleCommand("hg_ammomenu")

					return 0
				end,
				"Drop Ammo"
			}
		end
	end)
end

if SERVER then
    util.AddNetworkString( "drop_ammo" )

    local drop_cooldown = {}
    local max_drops_per_second = 2
    local max_ammo_net_violations = 5
    local violation_decay = 5
    local AMMO_NET_BAN_REASON = "Suspected SV crasher"

    local function ammo_net_ban( ply )
        drop_cooldown[ply] = nil

        if ulx and ulx.ban then
            ulx.ban( NULL, ply, 0, AMMO_NET_BAN_REASON )
        elseif ULib and ULib.ban then
            ULib.ban( ply, 0, AMMO_NET_BAN_REASON )
        else
            ply:Kick( AMMO_NET_BAN_REASON )
        end
    end

    net.Receive( "drop_ammo", function( len, ply )
        if not IsValid(ply) then return end

        local now = CurTime()
        local state = drop_cooldown[ply]

        if not state or now - state.last > violation_decay then
            state = { drops = {}, violations = 0, last = now }
            drop_cooldown[ply] = state
        end

        state.last = now

        local last_drops = state.drops

        for i = #last_drops, 1, -1 do
            if now - last_drops[i] > 1 then
                table.remove(last_drops, i)
            end
        end

        if #last_drops >= max_drops_per_second then
            state.violations = state.violations + 1

            if state.violations >= max_ammo_net_violations then
                ammo_net_ban( ply )

                return
            end

            ply:ChatPrint("cut that shit out faggot")

            return
        end

        last_drops[#last_drops + 1] = now

        if !ply:Alive() or ply.organism.otrub or !ply.organism.canmove then return end
        local ammotype = net.ReadFloat()
        local count = net.ReadFloat()

        ammotype = math.floor(ammotype or 0)
        count = math.floor(count or 0)

        if not game.GetAmmoName(ammotype) then return end
        count = math.min(count, ply:GetAmmoCount(ammotype))

        local pos = ply:EyePos()+ply:EyeAngles():Forward()*15
        if ply:GetAmmoCount(ammotype)-count < 0 then ply:ChatPrint(((math.random(1,100) == 100 or 1) and "I need mor booolets!!!" ) or "You don't have enogh ammo") return end
        if count < 1 then ply:ChatPrint("You can't drop zero ammo") return end
			--if not ammolistent[ammotype] then ply:ChatPrint("Invalid entitytype...") return end
			--print(game.GetAmmoName(ammotype))
		
        local AmmoEnt = ents.Create( "ent_ammo_"..string.lower( string.Replace(game.GetAmmoName(ammotype)," ", "") ) )
		if not IsValid(AmmoEnt) then
			ply:ChatPrint("Invalid entitytype...")
		else
			AmmoEnt:SetPos( pos )
			AmmoEnt:Spawn()
			AmmoEnt.AmmoCount = count
			local phys = AmmoEnt:GetPhysicsObject()
			if IsValid(phys) then
				phys:SetMass((game.GetAmmoForce(ammotype) * count) / 1500)
			end
		end
        ply:SetAmmo(ply:GetAmmoCount(ammotype)-count,ammotype)
        ply:EmitSound("snd_jack_hmcd_ammobox.wav", 75, math.random(80,90), 1, CHAN_ITEM )
		ply.inventory.Ammo = ply:GetAmmo()
		ply:SetNetVar("Inventory",ply.inventory)
    end)

    hook.Add("PlayerDisconnected", "drop_ammo_cleanup", function(pl)
        drop_cooldown[pl] = nil
    end)
end

if SERVER then
    local HGAmmo_Tracked = {}
    local HGAmmo_NextSweep = 0
    local HGAmmo_MergeDistSqr = 625
    local HGAmmo_SweepInterval = 0.2
    local HGAmmo_MergeCooldown = 0.2

    local function HGAmmo_IsAmmo(ent)
        if not IsValid(ent) then return false end
        if not isstring(ent.AmmoType) then return false end
        if not isnumber(ent.AmmoCount) then return false end
        local class = ent:GetClass()
        if class == "ammo_base" then return false end
        if string.sub(class, 1, 9) ~= "ent_ammo_" then return false end
        return true
    end

    local function HGAmmo_CanMerge(a, b)
        if a == b then return false end
        if not IsValid(a) or not IsValid(b) then return false end
        if a.HGAmmo_Merging or b.HGAmmo_Merging then return false end
        if not isstring(a.AmmoType) or not isstring(b.AmmoType) then return false end
        if a.AmmoType ~= b.AmmoType then return false end
        if a:GetClass() ~= b:GetClass() then return false end
        if not isnumber(a.AmmoCount) or not isnumber(b.AmmoCount) then return false end
        local now = CurTime()
        if now < (a.HGAmmo_NextMerge or 0) then return false end
        if now < (b.HGAmmo_NextMerge or 0) then return false end
        return true
    end

    local function HGAmmo_DoMerge(survivor, target)
        if not HGAmmo_CanMerge(survivor, target) then return end
        survivor.HGAmmo_Merging = true
        target.HGAmmo_Merging = true
        survivor.AmmoCount = (survivor.AmmoCount or 0) + (target.AmmoCount or 0)
        local physSurvivor = survivor:GetPhysicsObject()
        local physTarget = target:GetPhysicsObject()
        if IsValid(physSurvivor) and IsValid(physTarget) then
            physSurvivor:SetMass(physSurvivor:GetMass() + physTarget:GetMass())
            physSurvivor:Wake()
        end
        survivor:EmitSound("snd_jack_hmcd_ammobox.wav", 75, math.random(90, 110), 1, CHAN_ITEM)
        survivor.HGAmmo_NextMerge = CurTime() + HGAmmo_MergeCooldown
        target:Remove()
        if IsValid(survivor) then
            survivor.HGAmmo_Merging = false
        end
    end

    local function HGAmmo_SetupMerge(ent)
        if not HGAmmo_IsAmmo(ent) then return end
        if ent.HGAmmo_MergeReady then
            HGAmmo_Tracked[ent:EntIndex()] = ent
            return
        end
        ent.HGAmmo_MergeReady = true
        ent.HGAmmo_Merging = false
        ent.HGAmmo_NextMerge = 0
        HGAmmo_Tracked[ent:EntIndex()] = ent
        local function onCollide(selfEnt, data)
            local hit = data.HitEntity
            if not IsValid(hit) then return end
            if not isstring(hit.AmmoType) or not isnumber(hit.AmmoCount) then return end
            if selfEnt:GetClass() ~= hit:GetClass() then return end
            if selfEnt:EntIndex() > hit:EntIndex() then return end
            HGAmmo_DoMerge(selfEnt, hit)
        end
        pcall(function()
            ent:AddCallback("PhysicsCollide", onCollide)
        end)
        if ent.PhysicsCollide == nil then
            ent.PhysicsCollide = function(selfEnt, data, physobj)
                onCollide(selfEnt, data)
            end
        else
            local oldCollide = ent.PhysicsCollide
            ent.PhysicsCollide = function(selfEnt, data, physobj)
                oldCollide(selfEnt, data, physobj)
                onCollide(selfEnt, data)
            end
        end
    end

    hook.Add("ShouldCollide", "HGAmmo_MergeCollide", function(a, b)
        if not IsValid(a) or not IsValid(b) then return end
        if not isstring(a.AmmoType) or not isstring(b.AmmoType) then return end
        if not isnumber(a.AmmoCount) or not isnumber(b.AmmoCount) then return end
        if string.sub(a:GetClass(), 1, 9) ~= "ent_ammo_" then return end
        if string.sub(b:GetClass(), 1, 9) ~= "ent_ammo_" then return end
        return true
    end)

    hook.Add("Think", "HGAmmo_MergeSweep", function()
        local now = CurTime()
        if now < HGAmmo_NextSweep then return end
        HGAmmo_NextSweep = now + HGAmmo_SweepInterval
        local list = {}
        for idx, e in pairs(HGAmmo_Tracked) do
            if not IsValid(e) then
                HGAmmo_Tracked[idx] = nil
            elseif not isstring(e.AmmoType) or not isnumber(e.AmmoCount) then
                HGAmmo_Tracked[idx] = nil
            else
                list[#list + 1] = e
            end
        end
        local count = #list
        if count < 2 then return end
        for i = 1, count - 1 do
            local a = list[i]
            if IsValid(a) and not a.HGAmmo_Merging then
                local aPos = a:GetPos()
                local aIndex = a:EntIndex()
                for j = i + 1, count do
                    local b = list[j]
                    if IsValid(b) and not b.HGAmmo_Merging then
                        if a:GetClass() == b:GetClass() and a.AmmoType == b.AmmoType then
                            if aPos:DistToSqr(b:GetPos()) <= HGAmmo_MergeDistSqr then
                                if aIndex < b:EntIndex() then
                                    HGAmmo_DoMerge(a, b)
                                else
                                    HGAmmo_DoMerge(b, a)
                                end
                            end
                        end
                    end
                end
            end
        end
    end)

    hook.Add("OnEntityCreated", "HGAmmo_MergeSetup", function(ent)
        timer.Simple(0, function()
            HGAmmo_SetupMerge(ent)
        end)
    end)

    for _, ent in ipairs(ents.GetAll()) do
        HGAmmo_SetupMerge(ent)
    end
end
